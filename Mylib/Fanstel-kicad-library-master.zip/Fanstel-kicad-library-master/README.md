# Fanstel KiCAD library

You can use this as a project template, or you can use the add the Fanstel-modules.lib and Fanstel-modules.pretty into your project.

![Footprints](/Images/Footprint.PNG)
